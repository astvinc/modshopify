<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:
 
The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
',
    'readme' => '*******************************************
* Extra: modShopify
* Developer: Marc Loehe (@boundaryfunc)
* Version: 1.0-alpha
*******************************************

A modX extra to show products via Shopify Products.

# Installation

1. Install phpThumbOf-Extra.
2. In the backend of your shop, create a new private app.
3. Install modShopify-Extra.
4. Enter credentials (Api Key, Password, Shared Token) for your private Shopify App while installing or later in modX\' system settings.
5. You can now use the snippet showProducts.

# Usage

    [[showProducts]]
    
## Options:

 * &limit: Amount of results (default: 50, max. 250)
 * &page: Page of results to show (default: 1)
 * &published_status: Show only published products (default: published, possible values: published|unpublished|any)
 * &vendor: Filter products by vendor
 * &handle: Filter products by handle
     
 * &containerTpl: Tpl Chunk for the outer container
 * &productTpl: Tpl Chunk for a single product
 * &productImgTpl: Tpl Chunk for a single product image
 * &productVariantTpl: Tpl Chunk for a single product variant
     
 * &thumbsWidth: Width of thumbs
 * &thumbsHeight: Height of thumbs
 * &thumbsArgs: Additional Arguments for phpThumbOf
    
',
    'changelog' => 'Changelog

ModShopify 1.0-alpha
====================================
- Initial commit
',
    'setup-options' => 'modshopify-1.0-beta3/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '39e604d51de7d14851b9c7352726ed9b',
      'native_key' => 'modshopify',
      'filename' => 'modNamespace/6e3198e04b1601be0cb77bb54068a1cc.vehicle',
      'namespace' => 'modshopify',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53e2fce768bdb9a27f8eacbea95dc654',
      'native_key' => 'modshopify.multipass_secret',
      'filename' => 'modSystemSetting/3b21bb2ce76cc8fbc42d8dced2e10fa2.vehicle',
      'namespace' => 'modshopify',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1ddefdfc83ef6315047b5189fd7fa0e',
      'native_key' => 'modshopify.api_key',
      'filename' => 'modSystemSetting/95f3541ca21d26f2f0e8f9c42aee8461.vehicle',
      'namespace' => 'modshopify',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9fc7e8232322f44347172ade70b68eb',
      'native_key' => 'modshopify.auth_secret',
      'filename' => 'modSystemSetting/89c933fd8e60e83e36250b2c05deaf3e.vehicle',
      'namespace' => 'modshopify',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0883bda669275f9186b2628796eaab9f',
      'native_key' => 'modshopify.auth_token',
      'filename' => 'modSystemSetting/aa3ca81011ce2a448efb47d92d2cbbb3.vehicle',
      'namespace' => 'modshopify',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22a6fad607d73b369bcfa6d47cc78db2',
      'native_key' => 'modshopify.shop_domain',
      'filename' => 'modSystemSetting/ea583aab9fd087b65ec56dddd5abf995.vehicle',
      'namespace' => 'modshopify',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '802cd62f871070971e915485bd2a5f25',
      'native_key' => 1,
      'filename' => 'modCategory/fac2444d6b3237da227a317d45f90f30.vehicle',
      'namespace' => 'modshopify',
    ),
  ),
);