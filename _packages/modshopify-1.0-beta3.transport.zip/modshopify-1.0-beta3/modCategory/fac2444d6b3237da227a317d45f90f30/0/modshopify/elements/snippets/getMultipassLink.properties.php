<?php
return array( 
  'tpl' => 'modShopifyProductMultipassLink', 
  'domain' => 'https://ediets.myshopify.com',
  'path' => '/',
  'return_url'=>'https://ediets.myshopify.com'
);