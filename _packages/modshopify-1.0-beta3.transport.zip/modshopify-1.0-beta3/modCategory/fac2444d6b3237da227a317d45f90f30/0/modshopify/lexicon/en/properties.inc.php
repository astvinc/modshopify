<?php

$_lang['modshopify.prop_desc.limit'] = 'Amount of results (default: 50, max. 250)';
$_lang['modshopify.prop_desc.page'] = 'Page of results to show (default: 1)';
$_lang['modshopify.prop_desc.published_status'] = 'Show only published products (default: published, possible values: published|unpublished|any)';
$_lang['modshopify.prop_desc.containerTpl'] = 'Tpl Chunk for the outer container';
$_lang['modshopify.prop_desc.productTpl'] = 'Tpl Chunk for a single product';
$_lang['modshopify.prop_desc.productImgTpl'] = 'Tpl Chunk for a single product image';
$_lang['modshopify.prop_desc.productVariantTpl'] = 'Tpl Chunk for a single product variant';
$_lang['modshopify.prop_desc.thumbsWidth'] = 'Width of thumbs';
$_lang['modshopify.prop_desc.thumbsHeight'] = 'Height of thumbs';
$_lang['modshopify.prop_desc.thumbsArgs'] = 'Additional Arguments for phpThumbOf';
